# -CodingDojo-Yahtzee
A C# version of Yahtzee rules

You can find the rules [here](http://www.ludovalais.ch/img_docjeux/Yahtzee+classique.pdf)
